Sticky Notes Django project.

To run locally:
1. Create a venv: python -m venv venv
2. Activate venv and install Django: pip install django
3. Run migrations: python manage.py migrate
4. Run server: python manage.py runserver
