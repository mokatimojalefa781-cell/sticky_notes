from django.test import TestCase
from .models import Note

class NotesTests(TestCase):
    def test_create_note(self):
        n = Note.objects.create(title='Test', content='Content')
        self.assertEqual(n.title, 'Test')

    def test_update_note(self):
        n = Note.objects.create(title='Old', content='x')
        n.title = 'New'
        n.save()
        self.assertEqual(Note.objects.get(pk=n.pk).title, 'New')

    def test_delete_note(self):
        n = Note.objects.create(title='ToDelete')
        pk = n.pk
        n.delete()
        self.assertFalse(Note.objects.filter(pk=pk).exists())
